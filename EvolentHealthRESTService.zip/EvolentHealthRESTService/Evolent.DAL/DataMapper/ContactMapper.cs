﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.DAL.Models;

namespace Evolent.DAL.DataMapper
{
    public class ContactMapper : IContactMapper
    {
        public ContactEntity MapToContactEntity(ContactInfo entity)
        {
            return new ContactEntity()
            {
                ID = entity.ID,
                FirstName = entity.FirstName,
                LastName = entity.LastName,
                Email = entity.Email,
                Phone = entity.Phone,
                Status = entity.Status,
                CreatedBy = entity.CreatedBy,
                CreadedDate = entity.CreadedDate,
                ModifiedBy = entity.ModifiedBy,
                ModifiedDate = entity.ModifiedDate
            };
        }

        public ContactInfo MapToContactoInfo(ContactEntity entity)
        {
            return new ContactInfo()
            {
                ID = entity.ID,
                FirstName = entity.FirstName,
                LastName = entity.LastName,
                Email = entity.Email,
                Phone = entity.Phone,
                Status = entity.Status,
                CreatedBy = entity.CreatedBy,
                CreadedDate = entity.CreadedDate,
                ModifiedBy = entity.ModifiedBy,
                ModifiedDate = entity.ModifiedDate
            };
        }

        //List<ContactEntity> MapToContactEntityList(List<ContactInfo> entity)
        //{
        //    List<ContactEntity> contactEntityList = new List<ContactEntity>();
        //    foreach (ContactInfo item in entity)
        //    {
        //        ContactEntity contactEntity = new ContactEntity() {
        //            ID = item.ID,
        //            FirstName = item.FirstName,
        //            LastName = item.LastName,
        //            Email = item.Email,
        //            Phone = item.Phone,
        //            Status = item.Status,
        //            CreatedBy = item.CreatedBy,
        //            CreadedDate = item.CreadedDate,
        //            ModifiedBy = item.ModifiedBy,
        //            ModifiedDate = item.ModifiedDate
        //        };
        //        contactEntityList.Add(contactEntity);
        //    }
        //    return contactEntityList;
        //}

        //List<ContactInfo> MapToContactoInfoList(List<ContactEntity> entity)
        //{
        //    List<ContactInfo> contactInfoList = new List<ContactInfo>();
        //    foreach (ContactEntity item in entity)
        //    {
        //        ContactInfo contactInfoEntity = new ContactInfo()
        //        {
        //            ID = item.ID,
        //            FirstName = item.FirstName,
        //            LastName = item.LastName,
        //            Email = item.Email,
        //            Phone = item.Phone,
        //            Status = item.Status,
        //            CreatedBy = item.CreatedBy,
        //            CreadedDate = item.CreadedDate,
        //            ModifiedBy = item.ModifiedBy,
        //            ModifiedDate = item.ModifiedDate
        //        };
        //        contactInfoList.Add(contactInfoEntity);
        //    }
        //    return contactInfoList;
        //}


        public List<ContactEntity> MapToContactEntityList(List<ContactInfo> entity)
        {
            List<ContactEntity> contactEntityList = new List<ContactEntity>();
            foreach (ContactInfo item in entity)
            {
                ContactEntity contactEntity = new ContactEntity()
                {
                    ID = item.ID,
                    FirstName = item.FirstName,
                    LastName = item.LastName,
                    Email = item.Email,
                    Phone = item.Phone,
                    Status = item.Status,
                    CreatedBy = item.CreatedBy,
                    CreadedDate = item.CreadedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate
                };
                contactEntityList.Add(contactEntity);
            }
            return contactEntityList;
        }

        public List<ContactInfo> MapToContactoInfoList(List<ContactEntity> entity)
        {
            List<ContactInfo> contactInfoList = new List<ContactInfo>();
            foreach (ContactEntity item in entity)
            {
                ContactInfo contactInfoEntity = new ContactInfo()
                {
                    ID = item.ID,
                    FirstName = item.FirstName,
                    LastName = item.LastName,
                    Email = item.Email,
                    Phone = item.Phone,
                    Status = item.Status,
                    CreatedBy = item.CreatedBy,
                    CreadedDate = item.CreadedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate
                };
                contactInfoList.Add(contactInfoEntity);
            }
            return contactInfoList;
        }
    }
}
