﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.DAL.Models;

namespace Evolent.DAL.DataMapper
{
    public interface IContactMapper
    {
        ContactEntity MapToContactEntity(ContactInfo e);
        ContactInfo MapToContactoInfo(ContactEntity e);
        List<ContactEntity> MapToContactEntityList(List<ContactInfo> e);
        List<ContactInfo> MapToContactoInfoList(List<ContactEntity> e);
    }
}
