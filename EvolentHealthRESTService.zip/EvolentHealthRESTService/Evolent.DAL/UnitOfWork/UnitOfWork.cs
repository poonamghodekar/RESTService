﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.DAL.Repository;

namespace Evolent.DAL.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ContactInfoEntities _context;
        private IContactRepository _contactRepositiory;

        public UnitOfWork()
        {
            _context = new ContactInfoEntities();
        }

        public IContactRepository ContactRepository
        {
            get
            {
                if (this._contactRepositiory == null)
                {
                    this._contactRepositiory = new ContactRepository(_context);
                }
                return this._contactRepositiory;
            }
        }

        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }
    }
}
