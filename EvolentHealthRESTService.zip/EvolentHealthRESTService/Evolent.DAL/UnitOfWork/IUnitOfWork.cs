﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.DAL.Repository;

namespace Evolent.DAL.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IContactRepository ContactRepository { get; }

        int SaveChanges();
    }

}
