﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.DAL.DataMapper;
using Evolent.DAL.Models;

namespace Evolent.DAL.Repository
{
    public class ContactRepository : IContactRepository
    {
        private readonly ContactInfoEntities _context;
        ContactMapper mapper;

        public ContactRepository(ContactInfoEntities context)
        {
            _context = context;
            mapper = new ContactMapper();
        }

        public IEnumerable<ContactEntity> GetContacts()
        {
            List<ContactInfo> contactInfoEntityList = _context.ContactInfoes.ToList();

            return mapper.MapToContactEntityList(contactInfoEntityList);
        }

        public ContactEntity GetContactByID(int contactId)
        {
            return mapper.MapToContactEntity(_context.ContactInfoes.Find(contactId));
        }

        public int InsertContact(ContactEntity contactEntity)
        {
            int result = -1;

            if (contactEntity != null)
            {
                _context.ContactInfoes.Add(mapper.MapToContactoInfo(contactEntity));
                _context.SaveChanges();
                result = contactEntity.ID;
            }

            return result;
        }

        public void DeleteContact(int contactId)
        {
            ContactInfo contactEntity = _context.ContactInfoes.Find(contactId);
            _context.ContactInfoes.Remove(contactEntity);
            _context.SaveChanges();
        }

        public int UpdateContact(ContactEntity contactEntity)
        {
            int result = -1;

            if (contactEntity != null)
            {
                _context.Entry(contactEntity).State = EntityState.Modified;
                _context.SaveChanges();
                result = contactEntity.ID;
            }

            return result;
        }

        //public void Save()
        //{
        //    _context.SaveChanges();
        //}

        //private bool disposed = false;

        //protected virtual void Dispose(bool disposing)
        //{
        //    if (!this.disposed)
        //    {
        //        if (disposing)
        //        {
        //            _context.Dispose();
        //        }
        //    }
        //    this.disposed = true;
        //}

        //public void Dispose()
        //{
        //    Dispose(true);

        //    GC.SuppressFinalize(this);
        //}
    }
}
