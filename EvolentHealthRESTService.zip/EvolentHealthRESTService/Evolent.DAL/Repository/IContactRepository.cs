﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.DAL.Models;

namespace Evolent.DAL.Repository
{
    public interface IContactRepository
    {
        IEnumerable<ContactEntity> GetContacts();
        ContactEntity GetContactByID(int studentId);
        int InsertContact(ContactEntity student);
        void DeleteContact(int contactID);
        int UpdateContact(ContactEntity student);
    }
}
